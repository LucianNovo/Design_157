jQuery(document).ready(function($) {
    $('.tagline').fontStretch();
});